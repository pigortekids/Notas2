Essa API � para uma biblioteca de livros.

Nela temos 3 tabelas:
-livro
-cliente
-aluguel

Onde voc� pode pegar, inserir, editar e deletar 
as informa��es de todas essas tabelas por requisi��es HTTP de 
GET, POST, PUT, DEL